from sqlalchemy import Column, Integer, String, Text
from app.db.database import Base

class Meeting(Base):
    __tablename__ = "meetings"

    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String, unique=True, index=True)
    transcript = Column(Text)
    summary = Column(Text)
    sentiment = Column(String)
    topics = Column(Text)
