from app.db.database import Base, engine
from app.models.meeting import Meeting

def init_db():
    Base.metadata.create_all(bind=engine)
