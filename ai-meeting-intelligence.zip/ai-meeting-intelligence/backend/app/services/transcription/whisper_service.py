import os
from whispercpp import Whisper

class TranscriptionService:
    def __init__(self):
        self.model = Whisper.from_pretrained("base.en") 
    
    def transcribe(self, file_path: str) -> str:
        #self.model.transcribe(file_path)
        self.model = Whisper.from_pretrained(model_path)

        return self.model.text()
'''
class TranscriptionService:
    def __init__(self, model_path: str ="models/ggml-base.en.bin"):
        #self.model = Whisper(model_path)
        self.model = Whisper.from_pretrained(model_path)

    def transcribe(self, file_path: str) -> str:
        #self.model.transcribe(file_path)
        self.model = Whisper.from_pretrained(model_path)

        return self.model.text()
'''